CREATE PROCEDURE `addCollege`(IN `collegeID`      INT(11), IN `collegeName` VARCHAR(15), IN `collegeTypeID` INT(11),
                              IN `collegeLevelID` INT(11), IN `loginUser` VARCHAR(15))
  BEGIN
	INSERT INTO college(
		CollegeID,
		CollegeName,
		collegeTypeID,
		collegeLevelID,
		InUser,
		LastEditUser
	)
	VALUES(
		collegeID,
		collegeName,
		collegeTypeID,
		collegeLevelID,
		loginUser,
		loginUser
	);
END