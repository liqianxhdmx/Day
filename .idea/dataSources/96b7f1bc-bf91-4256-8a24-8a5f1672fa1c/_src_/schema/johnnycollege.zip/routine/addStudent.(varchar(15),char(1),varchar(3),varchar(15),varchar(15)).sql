CREATE PROCEDURE `addStudent`(IN `studentName`    VARCHAR(15), IN `studentSex` CHAR(1), IN `studentAge` VARCHAR(3),
                              IN `cellphoneBrand` VARCHAR(15), IN `loginUser` VARCHAR(15))
  begin
	insert into student(
		StudentName,
		StudentSex,
		studentAge,
		cellphoneBrand,
		InUser,
		LastEditUser
	)
	values(
		studentName,
		studentSex,
		studentAge,
		cellphoneBrand,
		loginUser,
		loginUser
	);	
end